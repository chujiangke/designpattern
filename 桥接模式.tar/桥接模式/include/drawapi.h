#ifndef DRAWAPI_H
#define DRAWAPI_H
#include <iostream>
#include <string>
using namespace std;
class DrawAPI
{
 public:
  virtual void drawCircle(int radius, int x, int y) = 0;
};
#endif
